package clinicaVeterinaria.Controle;

import java.sql.*;
import javax.swing.JOptionPane;

public class VeterinarioDAO {
    public void CadastrarVet(Veterinario veterinario){
        String sql = "Insert into veterinario(nome,crm,formacao) values(?,?,?)";
        Connection con = null;
        con = new Conexao().getConnection();
        try{
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, veterinario.getNome());
            st.setString(2, veterinario.getCrm());
            st.setString(3, veterinario.getFormacao());
            st.execute();
            st.close();
            con.close();
        }catch(SQLException ex){
            System.out.println("Erro ao cadastrar "+ex);
        }
    }
    
    public void VisualizaVet(int tipo, Veterinario veterinario){
        Connection con = null;
        con = new Conexao().getConnection();
        if(tipo == 1){
            try{
                String sql = "SELECT * FROM veterinario WHERE nome = ?";
                PreparedStatement st = con.prepareStatement(sql);
                st.setString(1, veterinario.getNome());
                ResultSet rs = st.executeQuery();
                while (rs.next()) {
                    int id = rs.getInt("codigo");
                    String name = rs.getString("nome");
                    String formacao = rs.getString("formacao");
                    String crm = rs.getString("crm");
//                    System.out.println(id + "\t" + name + "\t" + formacao + "\t" + crm);
                    JOptionPane.showMessageDialog(null,
                            id + "\t" + name + "\t" + formacao + "\t" + crm);
                }
            }catch(SQLException ex){
                System.out.println("Erro: "+ex);
            }
        }else{
            try{
                String sql = "SELECT * FROM veterinario WHERE crm = ?";
                PreparedStatement st = con.prepareStatement(sql);
                st.setString(1, veterinario.getCrm());
                ResultSet rs = st.executeQuery();
                while (rs.next()) {
                    int id = rs.getInt("codigo");
                    String name = rs.getString("nome");
                    String formacao = rs.getString("formacao");
                    String crm = rs.getString("crm");
//                    System.out.println(id + "\t" + name + "\t" + formacao + "\t" + crm);
                    JOptionPane.showMessageDialog(null,
                            id + "\t" + name + "\t" + formacao + "\t" + crm);
                }
            }catch(SQLException ex){
                System.out.println("Erro: "+ex);
            }
        }
    }
}
