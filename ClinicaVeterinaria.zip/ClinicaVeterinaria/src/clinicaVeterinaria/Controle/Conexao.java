package clinicaVeterinaria.Controle;

import java.sql.*;

public class Conexao {
    public static Connection getConnection(){
        Connection conexao = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/clinica";
            String user = "root";
            String password = "";
            conexao = DriverManager.getConnection(url, user, password);
        }catch(SQLException ex){
            System.out.println("Erro "+ex);
        }catch(ClassNotFoundException ex){
            System.out.println("Erro: "+ex);
        }
        return conexao;
    }
}
