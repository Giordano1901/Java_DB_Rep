
import clinicaVeterinaria.View.cadastroVet;

public class Main {
    public static void main(String[] args) {        
        cadastroVet cadVet = new cadastroVet();
        cadVet.setVisible(true);
        cadVet.setLocationRelativeTo(null);
    }
    
}
