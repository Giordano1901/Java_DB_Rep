import java.sql.*;

public class Main {
    public static void main(String[] args) {

    Connection conn = null;
    try {
      // Carrega o driver JDBC do MySQL
      Class.forName("com.mysql.cj.jdbc.Driver");

      // Estabelece a conexão com o banco de dados
      String url = "jdbc:mysql://localhost:3306/clinica";
      String user = "root";
      String password = "";
      conn = DriverManager.getConnection(url, user, password);

      // Executa a consulta SQL
      Statement stmt = conn.createStatement();
      ResultSet rs = stmt.executeQuery("SELECT * FROM veterinario");

      // Processa o resultado da consulta SQL
      while (rs.next()) {
        System.out.println(rs.getString("formacao"));
      }
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      // Fecha a conexão com o banco de dados
      try {
        if (conn != null) {
          conn.close();
        }
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }
}
