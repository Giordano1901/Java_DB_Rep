import db.controle.conexao;
import db.view.cadastroVet;

public class Main {
    public static void main(String[] args) {
        conexao connect = new conexao();
        connect.getConnection();
        
        cadastroVet cVet = new cadastroVet();
        cVet.setVisible(true);
        cVet.setLocationRelativeTo(null);
        
    }
}
