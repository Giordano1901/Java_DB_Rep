package db.controle;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class conexao {
    public Connection getConnection(){
        Connection conn = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            String url = "jdbc:mysql://localhost:3306/clinica";
            String user = "root";
            String password = "";
            conn = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(conexao.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex){
            System.out.println("Erro: "+ex);
        }
        
        return conn;
    }
}
