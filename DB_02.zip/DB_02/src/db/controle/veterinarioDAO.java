package db.controle;

import db.controle.veterinario;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class veterinarioDAO {
    public void cadastrarVet(veterinario vet){
        String sql = "INSERT INTO veterinario(nome,crm,formacao) values(?,?,?)";
        Connection con = null;
        con = new conexao().getConnection();
        try {
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, vet.getNome());
            st.setString(2, vet.getCrm());
            st.setString(3, vet.getFormacao());
            int rows = st.executeUpdate();
            System.out.println(rows + " rows affected");
            st.close();
            con.close();
        } catch (SQLException ex) {
            System.out.println("Erro ao cadastrar "+ex);
        }
    }
}
